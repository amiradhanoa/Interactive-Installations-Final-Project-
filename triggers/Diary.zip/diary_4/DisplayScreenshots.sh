#!/bin/bash


open -a Max /Users/daledhanoa/Documents/GitHub/https---github.com-IDMNYU-DMUY-4913-B-InteractiveInstallation_SP18.git/II_FinalProject/triggers/diary_4/diary.maxpat 

